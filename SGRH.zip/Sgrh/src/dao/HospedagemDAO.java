/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package dao;

/**
 *
 * @author User
 */
import java.sql.*;
import model.Hospedagem;
public class HospedagemDAO {
    Connection conn;
    public void realizarCheckIn(Hospedagem objHospedagem) {
        conn = new ConexaoDAO().conectaBD();
        try {
            conn.setAutoCommit(false);
            
            String sqlUpdateQuarto = "UPDATE quartos SET estado = 'Ocupado' WHERE id = ?";
            try(PreparedStatement pstmUpdate = conn.prepareStatement(sqlUpdateQuarto)){
                pstmUpdate.setInt(1, objHospedagem.getIdQuarto());
                pstmUpdate.executeUpdate();
            }

            String sqlInsertHospedagem = "INSERT INTO hospedagens (id_quarto, id_hospede, id_funcionario, data_checkin, estado) VALUES (?, ?, ?, ?, ?)";
            try (PreparedStatement pstmInsert = conn.prepareStatement(sqlInsertHospedagem)) {
                pstmInsert.setInt(1, objHospedagem.getIdQuarto());
                pstmInsert.setInt(2, objHospedagem.getIdHospede());
                pstmInsert.setInt(3, objHospedagem.getIdFuncionario());
                pstmInsert.setTimestamp(4, Timestamp.valueOf(objHospedagem.getDataCheckin()));
                pstmInsert.setString(5, "Ativa");
                pstmInsert.execute();
            }
            
            conn.commit();
            System.out.println("\nCheck-in realizado com sucesso!");
        } catch (SQLException erro) {
            try {
                conn.rollback();
                System.out.println("HospedagemDAO CheckIn (Erro): " + erro + ". A operação foi cancelada.");
            } catch (SQLException e) {
                System.out.println("HospedagemDAO Rollback: " + e);
            }
        } finally {
             try {
                if(conn != null) {
                    conn.setAutoCommit(true);
                    conn.close();
                }
            } catch (SQLException ex) {
                System.out.println("HospedagemDAO setAutoCommit/close: " + ex);
            }
        }
    }
}
