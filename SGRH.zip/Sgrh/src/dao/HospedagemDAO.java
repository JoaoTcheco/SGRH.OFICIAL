/*
 * ========= PACOTE dao - Arquivo: HospedagemDAO.java =========
 * Este arquivo foi atualizado para incluir os métodos necessários
 * para o check-out e para listar as hospedagens ativas.
 */
package dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;
import model.Hospedagem;
import model.HospedagemInfo;
// Nova classe/DTO para informações detalhadas

public class HospedagemDAO {

    Connection conn;

    /**
     * Realiza o check-in de um hóspede, registando a hospedagem e atualizando o
     * estado do quarto.
     * Utiliza uma transação para garantir a consistência dos dados.
     * * @param objHospedagem O objeto Hospedagem com os dados do check-in.
     */
    public void realizarCheckIn(Hospedagem objHospedagem) {
        conn = new ConexaoDAO().conectaBD();
        try {
            // Inicia a transação
            conn.setAutoCommit(false);

            // 1. Atualiza o estado do quarto para 'Ocupado'
            String sqlUpdateQuarto = "UPDATE quartos SET estado = 'Ocupado' WHERE id = ?";
            try (PreparedStatement pstmUpdate = conn.prepareStatement(sqlUpdateQuarto)) {
                pstmUpdate.setInt(1, objHospedagem.getIdQuarto());
                pstmUpdate.executeUpdate();
            }

            // 2. Insere o registo da hospedagem
            String sqlInsertHospedagem = "INSERT INTO hospedagens (id_quarto, id_hospede, id_funcionario, data_checkin, estado) VALUES (?, ?, ?, ?, ?)";
            try (PreparedStatement pstmInsert = conn.prepareStatement(sqlInsertHospedagem)) {
                pstmInsert.setInt(1, objHospedagem.getIdQuarto());
                pstmInsert.setInt(2, objHospedagem.getIdHospede());
                pstmInsert.setInt(3, objHospedagem.getIdFuncionario());
                pstmInsert.setTimestamp(4, Timestamp.valueOf(objHospedagem.getDataCheckin()));
                pstmInsert.setString(5, "Ativa"); // Estado inicial da hospedagem
                pstmInsert.execute();
            }

            // Confirma a transação
            conn.commit();
            System.out.println("\nCheck-in realizado com sucesso!");

        } catch (SQLException erro) {
            try {
                // Em caso de erro, reverte a transação
                conn.rollback();
                System.out.println("HospedagemDAO CheckIn (Erro): " + erro.getMessage() + ". A operação foi cancelada.");
            } catch (SQLException e) {
                System.out.println("HospedagemDAO Rollback: " + e.getMessage());
            }
        } finally {
            try {
                if (conn != null) {
                    // Restaura o modo de auto-commit e fecha a conexão
                    conn.setAutoCommit(true);
                    conn.close();
                }
            } catch (SQLException ex) {
                System.out.println("HospedagemDAO setAutoCommit/close: " + ex.getMessage());
            }
        }
    }

    /**
     * Lista todas as hospedagens que estão atualmente ativas.
     * Junta informações das tabelas de hospedagens, quartos e hóspedes.
     * * @return Uma lista de objetos HospedagemInfo com detalhes das hospedagens
     * ativas.
     */
    public List < HospedagemInfo > listarHospedagensAtivas() {
        conn = new ConexaoDAO().conectaBD();
        String sql = "SELECT h.id, q.numero_quarto, ho.nome_completo AS nome_hospede, h.data_checkin, q.preco_por_noite " +
            "FROM hospedagens h " +
            "JOIN quartos q ON h.id_quarto = q.id " +
            "JOIN hospedes ho ON h.id_hospede = ho.id " +
            "WHERE h.estado = 'Ativa' ORDER BY h.data_checkin";
        List < HospedagemInfo > lista = new ArrayList < > ();

        try (PreparedStatement pstm = conn.prepareStatement(sql); ResultSet rs = pstm.executeQuery()) {

            while (rs.next()) {
                HospedagemInfo info = new HospedagemInfo();
                info.setIdHospedagem(rs.getInt("id"));
                info.setNumeroQuarto(rs.getString("numero_quarto"));
                info.setNomeHospede(rs.getString("nome_hospede"));
                info.setDataCheckin(rs.getTimestamp("data_checkin").toLocalDateTime());
                info.setPrecoPorNoite(rs.getDouble("preco_por_noite"));
                lista.add(info);
            }
        } catch (SQLException erro) {
            System.out.println("HospedagemDAO Listar Ativas: " + erro.getMessage());
        } finally {
            try {
                if (conn != null) conn.close();
            } catch (SQLException e) {
                System.out.println("Erro ao fechar conexão: " + e.getMessage());
            }
        }
        return lista;
    }

    /**
     * Realiza o check-out de uma hospedagem, atualizando seu estado e o do
     * quarto.
     * * @param idHospedagem O ID da hospedagem a ser finalizada.
     * @param dataCheckout A data e hora em que o check-out foi realizado.
     */
    public void realizarCheckOut(int idHospedagem, LocalDateTime dataCheckout) {
        conn = new ConexaoDAO().conectaBD();
        try {
            conn.setAutoCommit(false);

            // 1. Obter o id_quarto antes de atualizar a hospedagem
            int idQuarto = 0;
            String sqlSelectQuarto = "SELECT id_quarto FROM hospedagens WHERE id = ?";
            try (PreparedStatement pstmSelect = conn.prepareStatement(sqlSelectQuarto)) {
                pstmSelect.setInt(1, idHospedagem);
                ResultSet rs = pstmSelect.executeQuery();
                if (rs.next()) {
                    idQuarto = rs.getInt("id_quarto");
                } else {
                    throw new SQLException("Hospedagem não encontrada, ID: " + idHospedagem);
                }
            }

            // 2. Atualiza a hospedagem para 'Finalizada' e define a data de checkout
            String sqlUpdateHospedagem = "UPDATE hospedagens SET estado = 'Finalizada', data_checkout = ? WHERE id = ?";
            try (PreparedStatement pstmUpdateHosp = conn.prepareStatement(sqlUpdateHospedagem)) {
                pstmUpdateHosp.setTimestamp(1, Timestamp.valueOf(dataCheckout));
                pstmUpdateHosp.setInt(2, idHospedagem);
                pstmUpdateHosp.executeUpdate();
            }

            // 3. Atualiza o estado do quarto para 'Vago'
            String sqlUpdateQuarto = "UPDATE quartos SET estado = 'Vago' WHERE id = ?";
            try (PreparedStatement pstmUpdateQuarto = conn.prepareStatement(sqlUpdateQuarto)) {
                pstmUpdateQuarto.setInt(1, idQuarto);
                pstmUpdateQuarto.executeUpdate();
            }

            conn.commit();
            System.out.println("\nCheck-out realizado com sucesso!");

        } catch (SQLException erro) {
            try {
                conn.rollback();
                System.out.println("HospedagemDAO CheckOut (Erro): " + erro.getMessage() + ". A operação foi cancelada.");
            } catch (SQLException e) {
                System.out.println("HospedagemDAO Rollback: " + e.getMessage());
            }
        } finally {
            try {
                if (conn != null) {
                    conn.setAutoCommit(true);
                    conn.close();
                }
            } catch (SQLException ex) {
                System.out.println("HospedagemDAO setAutoCommit/close: " + ex.getMessage());
            }
        }
    }
}
