/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package dao;

/**
 *
 * @author User
 */
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import model.Funcionario;
public class FuncionarioDAO {
    Connection conn;
    public Funcionario autenticacaoFuncionario(Funcionario objFuncionario) {
        conn = new ConexaoDAO().conectaBD();
        Funcionario funcionarioAutenticado = null;
        try {
            String sql = "SELECT * FROM funcionarios WHERE username = ? AND senha = ?";
            PreparedStatement pstm = conn.prepareStatement(sql);
            pstm.setString(1, objFuncionario.getUsername());
            pstm.setString(2, objFuncionario.getSenha());
            ResultSet rs = pstm.executeQuery();
            if (rs.next()) {
                funcionarioAutenticado = new Funcionario();
                funcionarioAutenticado.setId(rs.getInt("id"));
                funcionarioAutenticado.setNomeCompleto(rs.getString("nome_completo"));
                funcionarioAutenticado.setUsername(rs.getString("username"));
            }
            pstm.close();
            conn.close();
        } catch (SQLException erro) {
            System.out.println("FuncionarioDAO: " + erro);
        }
        return funcionarioAutenticado;
    }
}
