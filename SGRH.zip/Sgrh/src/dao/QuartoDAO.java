/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package dao;

/**
 *
 * @author User
 */
import java.sql.*;
import java.util.ArrayList;
import java.util.List;
import model.Quarto;
public class QuartoDAO {
    Connection conn;
    public void cadastrarQuarto(Quarto objQuarto) {
        conn = new ConexaoDAO().conectaBD();
        String sql = "INSERT INTO quartos (numero_quarto, tipo_quarto, preco_por_noite, estado) VALUES (?, ?, ?, ?)";
        try (PreparedStatement pstm = conn.prepareStatement(sql)) {
            pstm.setString(1, objQuarto.getNumeroQuarto());
            pstm.setString(2, objQuarto.getTipoQuarto());
            pstm.setDouble(3, objQuarto.getPrecoPorNoite());
            pstm.setString(4, objQuarto.getEstado());
            pstm.execute();
            System.out.println("Quarto Cadastrado com Sucesso!");
            conn.close();
        } catch (SQLException erro) {
            System.out.println("QuartoDAO Cadastrar: " + erro);
        }
    }
    public List<Quarto> listarQuartos() {
        conn = new ConexaoDAO().conectaBD();
        String sql = "SELECT * FROM quartos ORDER BY numero_quarto";
        List<Quarto> lista = new ArrayList<>();
        try (PreparedStatement pstm = conn.prepareStatement(sql); ResultSet rs = pstm.executeQuery()) {
            while (rs.next()) {
                Quarto objQuarto = new Quarto();
                objQuarto.setId(rs.getInt("id"));
                objQuarto.setNumeroQuarto(rs.getString("numero_quarto"));
                objQuarto.setTipoQuarto(rs.getString("tipo_quarto"));
                objQuarto.setPrecoPorNoite(rs.getDouble("preco_por_noite"));
                objQuarto.setEstado(rs.getString("estado"));
                lista.add(objQuarto);
            }
            conn.close();
        } catch (SQLException erro) {
            System.out.println("QuartoDAO Listar: " + erro);
        }
        return lista;
    }
    public List<Quarto> listarQuartosPorEstado(String estado) {
         conn = new ConexaoDAO().conectaBD();
        String sql = "SELECT * FROM quartos WHERE estado = ? ORDER BY numero_quarto";
        List<Quarto> lista = new ArrayList<>();
        try (PreparedStatement pstm = conn.prepareStatement(sql)) {
            pstm.setString(1, estado);
            ResultSet rs = pstm.executeQuery();
            while (rs.next()) {
                Quarto objQuarto = new Quarto();
                objQuarto.setId(rs.getInt("id"));
                objQuarto.setNumeroQuarto(rs.getString("numero_quarto"));
                objQuarto.setTipoQuarto(rs.getString("tipo_quarto"));
                objQuarto.setPrecoPorNoite(rs.getDouble("preco_por_noite"));
                objQuarto.setEstado(rs.getString("estado"));
                lista.add(objQuarto);
            }
            conn.close();
        } catch (SQLException erro) {
            System.out.println("QuartoDAO ListarPorEstado: " + erro);
        }
        return lista;
    }
    public void atualizarQuarto(Quarto objQuarto) {
        conn = new ConexaoDAO().conectaBD();
        String sql = "UPDATE quartos SET numero_quarto = ?, tipo_quarto = ?, preco_por_noite = ?, estado = ? WHERE id = ?";
        try (PreparedStatement pstm = conn.prepareStatement(sql)) {
            pstm.setString(1, objQuarto.getNumeroQuarto());
            pstm.setString(2, objQuarto.getTipoQuarto());
            pstm.setDouble(3, objQuarto.getPrecoPorNoite());
            pstm.setString(4, objQuarto.getEstado());
            pstm.setInt(5, objQuarto.getId());
            pstm.execute();
            System.out.println("Quarto Atualizado com Sucesso!");
            conn.close();
        } catch (SQLException erro) {
            System.out.println("QuartoDAO Atualizar: " + erro);
        }
    }
    public void excluirQuarto(int idQuarto) {
        conn = new ConexaoDAO().conectaBD();
        String sql = "DELETE FROM quartos WHERE id = ?";
        try (PreparedStatement pstm = conn.prepareStatement(sql)) {
            pstm.setInt(1, idQuarto);
            pstm.execute();
            System.out.println("Quarto Excluído com Sucesso!");
            conn.close();
        } catch (SQLException erro) {
            System.out.println("QuartoDAO Excluir: " + erro);
        }
    }
}
