/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package dao;

/**
 *
 * @author User
 */
import java.sql.*;
import model.Hospede;
public class HospedeDAO {
    Connection conn;
    public Hospede cadastrarHospede(Hospede objHospede) {
        conn = new ConexaoDAO().conectaBD();
        String sql = "INSERT INTO hospedes (nome_completo, tipo_documento, numero_documento, nacionalidade, contacto, email) VALUES (?, ?, ?, ?, ?, ?)";
        try (PreparedStatement pstm = conn.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) {
            pstm.setString(1, objHospede.getNomeCompleto());
            pstm.setString(2, objHospede.getTipoDocumento());
            pstm.setString(3, objHospede.getNumeroDocumento());
            pstm.setString(4, objHospede.getNacionalidade());
            pstm.setString(5, objHospede.getContacto());
            pstm.setString(6, objHospede.getEmail());
            int affectedRows = pstm.executeUpdate();
            if (affectedRows > 0) {
                try (ResultSet rs = pstm.getGeneratedKeys()) {
                    if (rs.next()) {
                        objHospede.setId(rs.getInt(1));
                    }
                }
            }
            conn.close();
            return objHospede;
        } catch (SQLException erro) {
            System.out.println("HospedeDAO Cadastrar: " + erro);
            return null;
        }
    }
}
