
package sgrh;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.time.temporal.ChronoUnit;
import java.util.List;
import java.util.Scanner;
import dao.FuncionarioDAO;
import dao.HospedagemDAO;
import dao.HospedeDAO;
import dao.QuartoDAO;
import model.Funcionario;
import model.Hospedagem;
import model.HospedagemInfo;
import model.Hospede;
import model.Quarto;

public class Sgrh {

    private static Funcionario funcionarioLogado;
    private static final Scanner scanner = new Scanner(System.in);
    private static final QuartoDAO quartoDAO = new QuartoDAO();
    private static final HospedeDAO hospedeDAO = new HospedeDAO();
    private static final HospedagemDAO hospedagemDAO = new HospedagemDAO();
    // Formatter para exibir datas de forma mais amigável
    private static final DateTimeFormatter formatter = DateTimeFormatter.ofPattern("dd/MM/yyyy HH:mm");


    public static void main(String[] args) {
        System.out.println("===================================================");
        System.out.println("=== SISTEMA DE GESTÃO DE RESERVAS DE HOTEL (SGRH) ===");
        System.out.println("===================================================");

        if (tentarLogin()) {
            exibirMenuPrincipal();
        }

        System.out.println("\nObrigado por usar o sistema. Até a próxima!");
        scanner.close();
    }

    private static boolean tentarLogin() {
        int tentativas = 3;
        while (tentativas > 0) {
            System.out.println("\n--- LOGIN DE FUNCIONÁRIO ---");
            System.out.print("Utilizador: ");
            String username = scanner.nextLine();
            System.out.print("Senha: ");
            String senha = scanner.nextLine();

            Funcionario objFuncionario = new Funcionario();
            objFuncionario.setUsername(username);
            objFuncionario.setSenha(senha);

            FuncionarioDAO dao = new FuncionarioDAO();
            funcionarioLogado = dao.autenticacaoFuncionario(objFuncionario);

            if (funcionarioLogado != null) {
                System.out.println("\nLogin realizado com sucesso! Bem-vindo(a), " + funcionarioLogado.getNomeCompleto() + ".");
                return true;
            } else {
                tentativas--;
                System.out.println("Utilizador ou senha inválida. Tentativas restantes: " + tentativas);
            }
        }
        System.out.println("Excedeu o número de tentativas de login. O sistema será encerrado.");
        return false;
    }

    private static void exibirMenuPrincipal() {
        int opcao = -1;
        while (opcao != 0) {
            System.out.println("\n--- PAINEL PRINCIPAL ---");
            System.out.println("1. Gestão de Quartos");
            System.out.println("2. Realizar Check-in de Hóspede");
            System.out.println("3. Realizar Check-out de Hóspede"); // Funcionalidade agora implementada
            System.out.println("0. Sair do Sistema");
            System.out.print("Escolha uma opção: ");

            try {
                opcao = Integer.parseInt(scanner.nextLine());

                switch (opcao) {
                    case 1:
                        menuGestaoQuartos();
                        break;
                    case 2:
                        realizarCheckIn();
                        break;
                    case 3:
                        realizarCheckOut(); // Chamada para o novo método
                        break;
                    case 0:
                        break;
                    default:
                        System.out.println("Opção inválida. Tente novamente.");
                }
            } catch (NumberFormatException e) {
                System.out.println("Erro: Por favor, insira um número válido.");
            }
        }
    }

    
    private static boolean confirmarOperacao(String mensagem) {
        while (true) {
            System.out.print(mensagem + " (S/N): ");
            String resposta = scanner.nextLine().trim().toUpperCase();
            if ("S".equals(resposta)) {
                return true;
            } else if ("N".equals(resposta)) {
                System.out.println("Operação cancelada pelo utilizador.");
                return false;
            } else {
                System.out.println("Resposta inválida. Por favor, digite 'S' para Sim ou 'N' para Não.");
            }
        }
    }

    // --- MTODOS DE GESTÃO DE QUARTOS ---
    private static void menuGestaoQuartos() {
        int opcao = -1;
        while (opcao != 0) {
            System.out.println("\n--- GESTÃO DE QUARTOS ---");
            System.out.println("1. Listar todos os Quartos");
            System.out.println("2. Cadastrar novo Quarto");
            System.out.println("3. Atualizar dados de um Quarto");
            System.out.println("4. Excluir um Quarto");
            System.out.println("0. Voltar ao Painel Principal");
            System.out.print("Escolha uma opção: ");

            try {
                opcao = Integer.parseInt(scanner.nextLine());
                switch (opcao) {
                    case 1:
                        listarQuartos();
                        break;
                    case 2:
                        cadastrarQuarto();
                        break;
                    case 3:
                        atualizarQuarto();
                        break;
                    case 4:
                        excluirQuarto();
                        break;
                    case 0:
                        break;
                    default:
                        System.out.println("Opção inválida.");
                }
            } catch (NumberFormatException e) {
                System.out.println("Erro: Por favor, insira um número válido.");
            }
        }
    }

    private static void listarQuartos() {
        System.out.println("\n--- LISTA DE QUARTOS ---");
        List < Quarto > lista = quartoDAO.listarQuartos();
        System.out.printf("%-5s | %-15s | %-15s | %-15s | %-10s\n",
            "ID", "NÚMERO", "TIPO", "PREÇO (MZN)",
            "ESTADO");
        System.out.println("-----------------------------------------------------------------------");
        for (Quarto q: lista) {
            System.out.printf("%-5d | %-15s | %-15s | %-15.2f | %-10s\n",
                q.getId(), q.getNumeroQuarto(), q.getTipoQuarto(), q.getPrecoPorNoite(),
                q.getEstado());
        }
        System.out.println("-----------------------------------------------------------------------");
    }

    private static void cadastrarQuarto() {
        System.out.println("\n--- CADASTRAR NOVO QUARTO ---");
        try {
            Quarto quarto = new Quarto();
            System.out.print("Número do Quarto: ");
            quarto.setNumeroQuarto(scanner.nextLine());
            System.out.print("Tipo do Quarto (Ex: Simples, Duplo, Suite): ");
            quarto.setTipoQuarto(scanner.nextLine());
            System.out.print("Preço por Noite (MZN): ");
            quarto.setPrecoPorNoite(Double.parseDouble(scanner.nextLine()));
            quarto.setEstado("Vago"); // Novos quartos são sempre vagos

            if (confirmarOperacao("Deseja confirmar o cadastro deste quarto?")) {
                quartoDAO.cadastrarQuarto(quarto);
            }

        } catch (Exception e) {
            System.out.println("Erro ao cadastrar quarto. Verifique os dados inseridos.");
        }
    }

    private static void atualizarQuarto() {
        listarQuartos();
        System.out.println("\n--- ATUALIZAR QUARTO ---");
        try {
            System.out.print("Digite o ID do quarto que deseja atualizar (ou 0 para cancelar): ");
            int id = Integer.parseInt(scanner.nextLine());
            if (id == 0) {
                System.out.println("Operação cancelada.");
                return;
            }

            Quarto quartoExistente = quartoDAO.getQuartoById(id);
            if (quartoExistente == null) {
                System.out.println("Quarto com ID " + id + " não encontrado.");
                return;
            }

            //  Impede a alteração de um quarto ocupado ***
            if ("Ocupado".equalsIgnoreCase(quartoExistente.getEstado())) {
                System.out.println("\nNão é possível alterar os dados de um quarto que está atualmente ocupado.");
                return; // Volta para o menu anterior
            }

            Quarto quarto = new Quarto();
            quarto.setId(id);
            System.out.print("Novo número do quarto (" + quartoExistente.getNumeroQuarto() + "): ");
            quarto.setNumeroQuarto(scanner.nextLine());
            System.out.print("Novo tipo do quarto (" + quartoExistente.getTipoQuarto() + "): ");
            quarto.setTipoQuarto(scanner.nextLine());
            System.out.print("Novo preço por noite (" + quartoExistente.getPrecoPorNoite() + "): ");
            quarto.setPrecoPorNoite(Double.parseDouble(scanner.nextLine()));
            System.out.print("Novo estado (Vago, Ocupado, Manutencao): ");
            quarto.setEstado(scanner.nextLine());

            if (confirmarOperacao("Deseja confirmar a atualização deste quarto?")) {
                quartoDAO.atualizarQuarto(quarto);
            }

        } catch (Exception e) {
            System.out.println("Erro ao atualizar quarto. Verifique o ID e os dados inseridos.");
        }
    }

    /**
     
     verifica se o quarto está ocupado antes de permitir a exclusau.
     */
    private static void excluirQuarto() {
        listarQuartos();
        System.out.println("\n--- EXCLUIR QUARTO ---");
        try {
            System.out.print("Digite o ID do quarto que deseja excluir (ou 0 para cancelar): ");
            int id = Integer.parseInt(scanner.nextLine());
            if (id == 0) {
                System.out.println("Operação cancelada.");
                return;
            }

            // Busca o quarto no banco de dados para verificar seu estado
            Quarto quartoParaExcluir = quartoDAO.getQuartoById(id);

            if (quartoParaExcluir == null) {
                System.out.println("Quarto com o ID " + id + " não encontrado.");
            } else if ("Ocupado".equalsIgnoreCase(quartoParaExcluir.getEstado())) {
                // Se estiver ocupado, exibe a mensagem e não faz nada, voltando ao menu.
                System.out.println("\nNão é possível excluir este quarto porque está ocupado.");
            } else {
                // Se não estiver ocupado, pede confirmação.
                if (confirmarOperacao("Tem a certeza que deseja excluir o Quarto " + quartoParaExcluir.getNumeroQuarto() + "?")) {
                    quartoDAO.excluirQuarto(id);
                    System.out.println("Quarto Excluído com Sucesso!");
                }
            }
        } catch (NumberFormatException e) {
            System.out.println("Erro: ID inválido. Por favor, insira um número.");
        }
    }

    // --- MÉTODO DE CHECK-IN ---
    private static void realizarCheckIn() {
        System.out.println("\n--- REALIZAR CHECK-IN ---");
        try {
            // Passo 1: Listar e selecionar o quarto
            System.out.println("\n** Quartos Vagos Disponíveis **");
            List < Quarto > quartosVagos = quartoDAO.listarQuartosPorEstado("Vago");
            if (quartosVagos.isEmpty()) {
                System.out.println("Nenhum quarto vago no momento. Não é possível fazer check-in.");
                return;
            }
            System.out.printf("%-5s | %-15s | %-15s | %-15s\n",
                "ID", "NÚMERO", "TIPO", "PREÇO (MZN)");
            System.out.println("-----------------------------------------------------------------");
            for (Quarto q: quartosVagos) {
                System.out.printf("%-5d | %-15s | %-15s | %-15.2f\n", q.getId(), q.getNumeroQuarto(),
                    q.getTipoQuarto(), q.getPrecoPorNoite());
            }
            System.out.print("\nDigite o ID do quarto escolhido (ou 0 para cancelar): ");
            int idQuarto = Integer.parseInt(scanner.nextLine());

            if (idQuarto == 0) {
                System.out.println("Operação cancelada.");
                return;
            }

            // Passso 2: Cadastrar os dados do hóspede
            System.out.println("\n** Dados do Hóspede **");
            Hospede hospede = new Hospede();
            System.out.print("Nome Completo: ");
            hospede.setNomeCompleto(scanner.nextLine());
            System.out.print("Tipo de Documento (BI, Passaporte, DIRE): ");
            hospede.setTipoDocumento(scanner.nextLine());
            System.out.print("Número do Documento: ");
            hospede.setNumeroDocumento(scanner.nextLine());
            System.out.print("Nacionalidade: ");
            hospede.setNacionalidade(scanner.nextLine());
            System.out.print("Contacto Telefónico: ");
            hospede.setContacto(scanner.nextLine());
            System.out.print("Email (opcional): ");
            hospede.setEmail(scanner.nextLine());

            // Cadastra o ospede e recupera o objeto com ID
            Hospede hospedeCadastrado = hospedeDAO.cadastrarHospede(hospede);

            if (hospedeCadastrado != null) {
                // Passo 3: Criar a hospedagem
                Hospedagem hospedagem = new Hospedagem();
                hospedagem.setIdQuarto(idQuarto);
                hospedagem.setIdHospede(hospedeCadastrado.getId());
                hospedagem.setIdFuncionario(funcionarioLogado.getId());
                hospedagem.setDataCheckin(LocalDateTime.now());


                // Passo 4: Confirmar a operacAo
                if (confirmarOperacao("Confirma o check-in para " + hospede.getNomeCompleto() + " no quarto ID " + idQuarto + "?")) {
                    hospedagemDAO.realizarCheckIn(hospedagem);
                } else {

                    System.out.println("Check-in cancelado. O registo do hóspede foi mantido na base de dados.");
                }

            } else {
                System.out.println("Falha ao cadastrar o hóspede. Check-in cancelado.");
            }

        } catch (Exception e) {
            System.out.println("Ocorreu um erro durante o processo de check-in: " + e.getMessage());
        }
    }

    /**
     ontrola o fluxo de check-out de um hóspede.
     */
    private static void realizarCheckOut() {
        System.out.println("\n--- REALIZAR CHECK-OUT ---");

        // 1. Listar hospedagens ativas para o funcionário escolher
        List < HospedagemInfo > ativas = hospedagemDAO.listarHospedagensAtivas();
        if (ativas.isEmpty()) {
            System.out.println("Não há nenhuma hospedagem ativa para fazer check-out.");
            return;
        }

        System.out.println("\n** Hospedagens Ativas **");
        System.out.printf("%-5s | %-10s | %-25s | %-20s\n", "ID", "QUARTO", "HÓSPEDE", "DATA CHECK-IN");
        System.out.println("------------------------------------------------------------------------");
        HospedagemInfo selecionada = null;
        for (HospedagemInfo info: ativas) {
            System.out.printf("%-5d | %-10s | %-25s | %-20s\n",
                info.getIdHospedagem(),
                info.getNumeroQuarto(),
                info.getNomeHospede(),
                info.getDataCheckin().format(formatter));
        }
        System.out.println("------------------------------------------------------------------------");

        try {
            // 2. Pedir ao funcionário para selecionar a hospedagem
            System.out.print("\nDigite o ID da hospedagem para fazer check-out (ou 0 para cancelar): ");
            int idHospedagem = Integer.parseInt(scanner.nextLine());
            if (idHospedagem == 0) {
                System.out.println("Operação cancelada.");
                return;
            }

            // Encontrar a hospedagem selecionada na lista para obter todos os dados
            for (HospedagemInfo info: ativas) {
                if (info.getIdHospedagem() == idHospedagem) {
                    selecionada = info;
                    break;
                }
            }

            if (selecionada == null) {
                System.out.println("ID de hospedagem inválido.");
                return;
            }

            // 3. Calcular o custo da estadia
            LocalDateTime dataCheckin = selecionada.getDataCheckin();
            LocalDateTime dataCheckout = LocalDateTime.now();

          
            long noites = ChronoUnit.DAYS.between(dataCheckin.toLocalDate(), dataCheckout.toLocalDate());
            if (noites == 0) {
                noites = 1;
            }

            double precoPorNoite = selecionada.getPrecoPorNoite();
            double custoTotal = noites * precoPorNoite;

            // 4. Apresentar o resumo e pedir confirmação
            System.out.println("\n--- RESUMO DO CHECK-OUT ---");
            System.out.println("Hóspede: " + selecionada.getNomeHospede());
            System.out.println("Quarto: " + selecionada.getNumeroQuarto());
            System.out.println("Data Check-in: " + dataCheckin.format(formatter));
            System.out.println("Data Check-out: " + dataCheckout.format(formatter));
            System.out.println("Total de noites: " + noites);
            System.out.println("Preço por noite: " + String.format("%.2f MZN", precoPorNoite));
            System.out.println("--------------------------------");
            System.out.println("CUSTO TOTAL: " + String.format("%.2f MZN", custoTotal));
            System.out.println("--------------------------------");

            // 5. Finalizar a operação
            if (confirmarOperacao("Confirmar o check-out e o pagamento?")) {
                hospedagemDAO.realizarCheckOut(idHospedagem, dataCheckout);
            }

        } catch (NumberFormatException e) {
            System.out.println("Erro: ID inválido. Por favor, insira um número.");
        } catch (Exception e) {
            System.out.println("Ocorreu um erro durante o processo de check-out: " + e.getMessage());
        }
    }
}
