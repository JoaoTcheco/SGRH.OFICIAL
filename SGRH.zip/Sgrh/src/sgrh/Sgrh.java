package sgrh;


/**
 *
 * @author User
 */
import java.time.LocalDateTime;
import java.util.List;
import java.util.Scanner;
import dao.FuncionarioDAO;
import dao.HospedagemDAO;
import dao.HospedeDAO;
import dao.QuartoDAO;
import model.Funcionario;
import model.Hospedagem;
import model.Hospede;
import model.Quarto;

/**
 * Classe principal que executa a aplicação de gestão de hotel via consola.
 */
public class Sgrh {

    private static Funcionario funcionarioLogado;
    private static Scanner scanner = new Scanner(System.in);
    private static QuartoDAO quartoDAO = new QuartoDAO();
    private static HospedeDAO hospedeDAO = new HospedeDAO();
    private static HospedagemDAO hospedagemDAO = new HospedagemDAO();

    public static void main(String[] args) {
        System.out.println("===================================================");
        System.out.println("=== SISTEMA DE GESTÃO DE RESERVAS DE HOTEL (SGRH) ===");
        System.out.println("===================================================");

        if (tentarLogin()) {
            exibirMenuPrincipal();
        }

        System.out.println("\nObrigado por usar o sistema. Até a próxima!");
        scanner.close();
    }

    private static boolean tentarLogin() {
        int tentativas = 3;
        while (tentativas > 0) {
            System.out.println("\n--- LOGIN DE FUNCIONÁRIO ---");
            System.out.print("Utilizador: ");
            String username = scanner.nextLine();
            System.out.print("Senha: ");
            String senha = scanner.nextLine();

            Funcionario objFuncionario = new Funcionario();
            objFuncionario.setUsername(username);
            objFuncionario.setSenha(senha);

            FuncionarioDAO dao = new FuncionarioDAO();
            funcionarioLogado = dao.autenticacaoFuncionario(objFuncionario);

            if (funcionarioLogado != null) {
                System.out.println("\nLogin realizado com sucesso! Bem-vindo(a), " + funcionarioLogado.getNomeCompleto() + ".");
                return true;
            } else {
                tentativas--;
                System.out.println("Utilizador ou senha inválida. Tentativas restantes: " + tentativas);
            }
        }
        System.out.println("Excedeu o número de tentativas de login. O sistema será encerrado.");
        return false;
    }

    private static void exibirMenuPrincipal() {
        int opcao = -1;
        while (opcao != 0) {
            System.out.println("\n--- PAINEL PRINCIPAL ---");
            System.out.println("1. Gestão de Quartos");
            System.out.println("2. Realizar Check-in de Hóspede");
            System.out.println("3. Realizar Check-out (Funcionalidade Futura)");
            System.out.println("0. Sair do Sistema");
            System.out.print("Escolha uma opção: ");

            try {
                opcao = Integer.parseInt(scanner.nextLine());

                switch (opcao) {
                    case 1:
                        menuGestaoQuartos();
                        break;
                    case 2:
                        realizarCheckIn();
                        break;
                    case 3:
                        System.out.println("\nFuncionalidade ainda não implementada.");
                        break;
                    case 0:
                        break;
                    default:
                        System.out.println("Opção inválida. Tente novamente.");
                }
            } catch (NumberFormatException e) {
                System.out.println("Erro: Por favor, insira um número válido.");
            }
        }
    }

    private static void menuGestaoQuartos() {
        int opcao = -1;
        while (opcao != 0) {
            System.out.println("\n--- GESTÃO DE QUARTOS ---");
            System.out.println("1. Listar todos os Quartos");
            System.out.println("2. Cadastrar novo Quarto");
            System.out.println("3. Atualizar dados de um Quarto");
            System.out.println("4. Excluir um Quarto");
            System.out.println("0. Voltar ao Painel Principal");
            System.out.print("Escolha uma opção: ");

            try {
                opcao = Integer.parseInt(scanner.nextLine());
                switch (opcao) {
                    case 1:
                        listarQuartos();
                        break;
                    case 2:
                        cadastrarQuarto();
                        break;
                    case 3:
                        atualizarQuarto();
                        break;
                    case 4:
                        excluirQuarto();
                        break;
                    case 0:
                        break;
                    default:
                        System.out.println("Opção inválida.");
                }
            } catch (NumberFormatException e) {
                System.out.println("Erro: Por favor, insira um número válido.");
            }
        }
    }

    private static void listarQuartos() {
        System.out.println("\n--- LISTA DE QUARTOS ---");
        List<Quarto> lista = quartoDAO.listarQuartos();
        System.out.printf("%-5s | %-15s | %-15s | %-15s | %-10s\n", "ID", "NÚMERO", "TIPO", "PREÇO (MZN)", "ESTADO");
        System.out.println("-----------------------------------------------------------------------");
        for (Quarto q : lista) {
            System.out.printf("%-5d | %-15s | %-15s | %-15.2f | %-10s\n", q.getId(), q.getNumeroQuarto(), q.getTipoQuarto(), q.getPrecoPorNoite(), q.getEstado());
        }
        System.out.println("-----------------------------------------------------------------------");
    }

    private static void cadastrarQuarto() {
        System.out.println("\n--- CADASTRAR NOVO QUARTO ---");
        try {
            Quarto quarto = new Quarto();
            System.out.print("Número do Quarto: ");
            quarto.setNumeroQuarto(scanner.nextLine());
            System.out.print("Tipo do Quarto (Ex: Simples, Duplo, Suite): ");
            quarto.setTipoQuarto(scanner.nextLine());
            System.out.print("Preço por Noite (MZN): ");
            quarto.setPrecoPorNoite(Double.parseDouble(scanner.nextLine()));
            quarto.setEstado("Vago"); // Novos quartos são sempre vagos

            quartoDAO.cadastrarQuarto(quarto);
        } catch (Exception e) {
            System.out.println("Erro ao cadastrar quarto. Verifique os dados inseridos.");
        }
    }

    private static void atualizarQuarto() {
        listarQuartos();
        System.out.println("\n--- ATUALIZAR QUARTO ---");
        try {
            System.out.print("Digite o ID do quarto que deseja atualizar: ");
            int id = Integer.parseInt(scanner.nextLine());

            Quarto quarto = new Quarto();
            quarto.setId(id);
            System.out.print("Novo número do quarto: ");
            quarto.setNumeroQuarto(scanner.nextLine());
            System.out.print("Novo tipo do quarto: ");
            quarto.setTipoQuarto(scanner.nextLine());
            System.out.print("Novo preço por noite: ");
            quarto.setPrecoPorNoite(Double.parseDouble(scanner.nextLine()));
            System.out.print("Novo estado (Vago, Ocupado, Manutencao): ");
            quarto.setEstado(scanner.nextLine());

            quartoDAO.atualizarQuarto(quarto);
        } catch (Exception e) {
            System.out.println("Erro ao atualizar quarto. Verifique o ID e os dados inseridos.");
        }
    }
    
    private static void excluirQuarto() {
        listarQuartos();
        System.out.println("\n--- EXCLUIR QUARTO ---");
        try {
            System.out.print("Digite o ID do quarto que deseja excluir: ");
            int id = Integer.parseInt(scanner.nextLine());
            quartoDAO.excluirQuarto(id);
        } catch (Exception e) {
            System.out.println("Erro ao excluir quarto. Verifique o ID.");
        }
    }

    private static void realizarCheckIn() {
        System.out.println("\n--- REALIZAR CHECK-IN ---");
        try {
            // Passo 1: Listar e selecionar o quarto
            System.out.println("\n** Quartos Vagos Disponíveis **");
            List<Quarto> quartosVagos = quartoDAO.listarQuartosPorEstado("Vago");
             if(quartosVagos.isEmpty()){
                System.out.println("Nenhum quarto vago no momento. Não é possível fazer check-in.");
                return;
            }
            System.out.printf("%-5s | %-15s | %-15s | %-15s\n", "ID", "NÚMERO", "TIPO", "PREÇO (MZN)");
            System.out.println("-----------------------------------------------------------------");
            for (Quarto q : quartosVagos) {
                 System.out.printf("%-5d | %-15s | %-15s | %-15.2f\n", q.getId(), q.getNumeroQuarto(), q.getTipoQuarto(), q.getPrecoPorNoite());
            }
            System.out.print("\nDigite o ID do quarto escolhido: ");
            int idQuarto = Integer.parseInt(scanner.nextLine());

            // Passo 2: Cadastrar os dados do hóspede
            System.out.println("\n** Dados do Hóspede **");
            Hospede hospede = new Hospede();
            System.out.print("Nome Completo: ");
            hospede.setNomeCompleto(scanner.nextLine());
            System.out.print("Tipo de Documento (BI, Passaporte, DIRE): ");
            hospede.setTipoDocumento(scanner.nextLine());
            System.out.print("Número do Documento: ");
            hospede.setNumeroDocumento(scanner.nextLine());
            System.out.print("Nacionalidade: ");
            hospede.setNacionalidade(scanner.nextLine());
            System.out.print("Contacto Telefónico: ");
            hospede.setContacto(scanner.nextLine());
            System.out.print("Email (opcional): ");
            hospede.setEmail(scanner.nextLine());

            // Cadastra o hóspede e recupera o objeto com ID
            Hospede hospedeCadastrado = hospedeDAO.cadastrarHospede(hospede);
            
            if (hospedeCadastrado != null) {
                // Passo 3: Criar a hospedagem
                Hospedagem hospedagem = new Hospedagem();
                hospedagem.setIdQuarto(idQuarto);
                hospedagem.setIdHospede(hospedeCadastrado.getId());
                hospedagem.setIdFuncionario(funcionarioLogado.getId());
                hospedagem.setDataCheckin(LocalDateTime.now());
                
                hospedagemDAO.realizarCheckIn(hospedagem);
            } else {
                System.out.println("Falha ao cadastrar o hóspede. Check-in cancelado.");
            }

        } catch (Exception e) {
            System.out.println("Ocorreu um erro durante o processo de check-in: " + e.getMessage());
        }
    }
}
