/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package model;

/**
 *
 * @author User
 */
public class Quarto {
    private int id;
    private String numeroQuarto;
    private String tipoQuarto;
    private double precoPorNoite;
    private String estado;
    public int getId() { return id; }
    public void setId(int id) { this.id = id; }
    public String getNumeroQuarto() { return numeroQuarto; }
    public void setNumeroQuarto(String numeroQuarto) { this.numeroQuarto = numeroQuarto; }
    public String getTipoQuarto() { return tipoQuarto; }
    public void setTipoQuarto(String tipoQuarto) { this.tipoQuarto = tipoQuarto; }
    public double getPrecoPorNoite() { return precoPorNoite; }
    public void setPrecoPorNoite(double precoPorNoite) { this.precoPorNoite = precoPorNoite; }
    public String getEstado() { return estado; }
    public void setEstado(String estado) { this.estado = estado; }
}

