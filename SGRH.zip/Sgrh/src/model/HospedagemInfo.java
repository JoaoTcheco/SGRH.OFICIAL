/* * ========= PACOTE model - Arquivo: HospedagemInfo.java =========
 * Crie este novo arquivo dentro do pacote 'model'.
 * É uma classe simples (DTO) para transportar dados combinados de várias tabelas
 * para a interface do utilizador de forma organizada.
 */
package model;

import java.time.LocalDateTime;

public class HospedagemInfo {
    private int idHospedagem;
    private String numeroQuarto;
    private String nomeHospede;
    private LocalDateTime dataCheckin;
    private double precoPorNoite;

    // Getters e Setters
    public int getIdHospedagem() { return idHospedagem; }
    public void setIdHospedagem(int idHospedagem) { this.idHospedagem = idHospedagem; }
    public String getNumeroQuarto() { return numeroQuarto; }
    public void setNumeroQuarto(String numeroQuarto) { this.numeroQuarto = numeroQuarto; }
    public String getNomeHospede() { return nomeHospede; }
    public void setNomeHospede(String nomeHospede) { this.nomeHospede = nomeHospede; }
    public LocalDateTime getDataCheckin() { return dataCheckin; }
    public void setDataCheckin(LocalDateTime dataCheckin) { this.dataCheckin = dataCheckin; }
    public double getPrecoPorNoite() { return precoPorNoite; }
    public void setPrecoPorNoite(double precoPorNoite) { this.precoPorNoite = precoPorNoite; }
}

