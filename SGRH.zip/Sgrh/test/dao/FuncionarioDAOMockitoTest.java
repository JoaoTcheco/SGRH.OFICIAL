/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import model.Funcionario;

// Imports estáticos do Mockito e JUnit
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import static org.mockito.Mockito.*;
import org.mockito.MockitoAnnotations;

/**
 * Demonstra como testar a classe FuncionarioDAO em isolamento da base de dados
 * usando o framework Mockito.
 *
 * @author User
 */
public class FuncionarioDAOMockitoTest {

    // @Mock cria um objeto falso (um "mock") para a classe/interface especificada.
    @Mock
    private Connection mockConnection;
    
    @Mock
    private PreparedStatement mockPreparedStatement;
    
    @Mock
    private ResultSet mockResultSet;

    // A classe ConexaoDAO também precisa ser "mockada" porque é instanciada
    // diretamente dentro do método que queremos testar.
    @Mock
    private ConexaoDAO mockConexaoDAO;

    // @InjectMocks tenta injetar os mocks criados com @Mock nos campos
    // da classe de teste. Neste caso, não vai funcionar diretamente porque
    // o FuncionarioDAO não foi desenhado para injeção, mas é uma boa prática.
    @InjectMocks
    private FuncionarioDAO funcionarioDAO;

    /**
     * O método setUp é executado antes de cada teste (@Test).
     * MockitoAnnotations.openMocks(this) inicializa todos os campos anotados com
     * @Mock e @InjectMocks nesta classe de teste.
     */
    @BeforeEach
    public void setUp() throws SQLException {
        MockitoAnnotations.openMocks(this);
        
        // --- Configuração Central do Comportamento dos Mocks ---
        // Aqui está a "magia". Estamos a dizer ao Mockito como os nossos objetos
        // falsos devem comportar-se quando os seus métodos são chamados.

        // 1. Quando new ConexaoDAO() for chamado no código, e depois .conectaBD()
        //    for invocado, queremos que devolva a nossa conexão FALSA.
        //    A forma de fazer isso é mockar o ConexaoDAO e o seu retorno.
        //    NOTA: A linha `new ConexaoDAO()` é o problema. A solução ideal seria
        //    mudar o código de FuncionarioDAO para receber o ConexaoDAO no construtor.
        //    Como não podemos, vamos mockar a cadeia de chamadas.
        when(mockConexaoDAO.conectaBD()).thenReturn(mockConnection);

        // 2. Quando o método mockConnection.prepareStatement() for chamado com QUALQUER
        //    string SQL, ele deve retornar o nosso PreparedStatement FALSO.
        when(mockConnection.prepareStatement(anyString())).thenReturn(mockPreparedStatement);

        // 3. Quando o método mockPreparedStatement.executeQuery() for chamado,
        //    ele deve retornar o nosso ResultSet FALSO.
        when(mockPreparedStatement.executeQuery()).thenReturn(mockResultSet);
    }

    @Test
    public void testAutenticacaoFuncionario_SucessoComMockito() throws SQLException {
        System.out.println("autenticacaoFuncionario com Mockito - Cenário de Sucesso");
        
        // --- ARRANGE (Preparar o cenário específico do teste) ---
        
        // Define o comportamento do ResultSet para um login bem-sucedido.
        // 1. Na primeira chamada a rs.next(), retorne 'true' (encontrou um registo).
        // 2. Em qualquer chamada subsequente, retorne 'false'.
        when(mockResultSet.next()).thenReturn(true).thenReturn(false);
        
        // Quando os getters forem chamados no ResultSet, retorne estes dados falsos.
        when(mockResultSet.getInt("id")).thenReturn(1);
        when(mockResultSet.getString("nome_completo")).thenReturn("Utilizador Mockado");
        when(mockResultSet.getString("username")).thenReturn("mockuser");

        // Objeto funcionário com os dados de login a serem testados
        Funcionario funcLogin = new Funcionario();
        funcLogin.setUsername("mockuser");
        funcLogin.setSenha("senha123");
        
        // *** O TRUQUE PARA LIDAR COM `new ConexaoDAO()` ***
        // Criamos uma subclasse anónima de FuncionarioDAO SÓ PARA ESTE TESTE.
        // Nela, substituímos o método que cria a conexão para usar o nosso mock.
        FuncionarioDAO daoParaTeste = new FuncionarioDAO() {
            public Connection conectaBD() {
                return mockConnection;
            }
        };


        // --- ACT (Executar a ação a ser testada) ---
        Funcionario funcionarioAutenticado = daoParaTeste.autenticacaoFuncionario(funcLogin);
        
        // --- ASSERT (Verificar os resultados) ---
        assertNotNull(funcionarioAutenticado, "O funcionário deveria ter sido autenticado.");
        assertEquals("mockuser", funcionarioAutenticado.getUsername(), "O username não é o esperado.");
        assertEquals("Utilizador Mockado", funcionarioAutenticado.getNomeCompleto(), "O nome completo não é o esperado.");
        
        // Opcional: Verificar se os métodos dos mocks foram chamados.
        // Isto garante que o seu código está a interagir com os objetos JDBC como esperado.
        verify(mockConnection, times(1)).prepareStatement(anyString());
        verify(mockPreparedStatement, times(1)).setString(1, "mockuser");
        verify(mockPreparedStatement, times(1)).setString(2, "senha123");
        verify(mockPreparedStatement, times(1)).executeQuery();
        verify(mockResultSet, times(1)).next();
    }
    
    @Test
    public void testAutenticacaoFuncionario_FalhaComMockito() throws SQLException {
        System.out.println("autenticacaoFuncionario com Mockito - Cenário de Falha");

        // --- ARRANGE ---
        // Para um login falhado, o ResultSet não encontrará nenhum registo.
        // Portanto, a chamada a rs.next() deve retornar 'false'.
        when(mockResultSet.next()).thenReturn(false);

        Funcionario funcLogin = new Funcionario();
        funcLogin.setUsername("user_errado");
        funcLogin.setSenha("senha_errada");
        
        // Reutilizamos a mesma estratégia da subclasse anónima
        FuncionarioDAO daoParaTeste = new FuncionarioDAO() {
            public Connection conectaBD() {
                return mockConnection;
            }
        };

        // --- ACT ---
        Funcionario funcionarioAutenticado = daoParaTeste.autenticacaoFuncionario(funcLogin);

        // --- ASSERT ---
        assertNull(funcionarioAutenticado, "A autenticação deveria ter falhado (retornar null).");
        
        // Verificações de interação
        verify(mockConnection, times(1)).prepareStatement(anyString());
        verify(mockPreparedStatement, times(1)).setString(1, "user_errado");
        verify(mockPreparedStatement, times(1)).setString(2, "senha_errada");
        verify(mockPreparedStatement, times(1)).executeQuery();
        // Garantir que não tentamos ler dados de um resultset vazio
        verify(mockResultSet, never()).getString(anyString()); 
    }
}