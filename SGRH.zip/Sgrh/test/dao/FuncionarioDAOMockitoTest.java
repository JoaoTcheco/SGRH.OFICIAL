/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import model.Funcionario;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import static org.mockito.Mockito.*;
import org.mockito.MockitoAnnotations;


public class FuncionarioDAOMockitoTest {

    
    @Mock
    private Connection mockConnection;
    
    @Mock
    private PreparedStatement mockPreparedStatement;
    
    @Mock
    private ResultSet mockResultSet;

    
    @Mock
    private ConexaoDAO mockConexaoDAO;

    
    @InjectMocks
    private FuncionarioDAO funcionarioDAO;

    
    @BeforeEach
    public void setUp() throws SQLException {
        MockitoAnnotations.openMocks(this);
        
        
        when(mockConexaoDAO.conectaBD()).thenReturn(mockConnection);

        when(mockConnection.prepareStatement(anyString())).thenReturn(mockPreparedStatement);

        when(mockPreparedStatement.executeQuery()).thenReturn(mockResultSet);
    }

    @Test
    public void testAutenticacaoFuncionario_SucessoComMockito() throws SQLException {
        System.out.println("autenticacaoFuncionario com Mockito - Cenário de Sucesso");
  
        when(mockResultSet.next()).thenReturn(true).thenReturn(false);
        

        when(mockResultSet.getInt("id")).thenReturn(1);
        when(mockResultSet.getString("nome_completo")).thenReturn("Utilizador Mockado");
        when(mockResultSet.getString("username")).thenReturn("mockuser");

        Funcionario funcLogin = new Funcionario();
        funcLogin.setUsername("mockuser");
        funcLogin.setSenha("senha123");

        FuncionarioDAO daoParaTeste = new FuncionarioDAO() {
            public Connection conectaBD() {
                return mockConnection;
            }
        };



        Funcionario funcionarioAutenticado = daoParaTeste.autenticacaoFuncionario(funcLogin);

        assertNotNull(funcionarioAutenticado, "O funcionário deveria ter sido autenticado.");
        assertEquals("mockuser", funcionarioAutenticado.getUsername(), "O username não é o esperado.");
        assertEquals("Utilizador Mockado", funcionarioAutenticado.getNomeCompleto(), "O nome completo não é o esperado.");

        verify(mockConnection, times(1)).prepareStatement(anyString());
        verify(mockPreparedStatement, times(1)).setString(1, "mockuser");
        verify(mockPreparedStatement, times(1)).setString(2, "senha123");
        verify(mockPreparedStatement, times(1)).executeQuery();
        verify(mockResultSet, times(1)).next();
    }
    
    @Test
    public void testAutenticacaoFuncionario_FalhaComMockito() throws SQLException {
        System.out.println("autenticacaoFuncionario com Mockito - Cenário de Falha");

        
        when(mockResultSet.next()).thenReturn(false);

        Funcionario funcLogin = new Funcionario();
        funcLogin.setUsername("user_errado");
        funcLogin.setSenha("senha_errada");
        

        FuncionarioDAO daoParaTeste = new FuncionarioDAO() {
            public Connection conectaBD() {
                return mockConnection;
            }
        };


        Funcionario funcionarioAutenticado = daoParaTeste.autenticacaoFuncionario(funcLogin);


        assertNull(funcionarioAutenticado, "A autenticação deveria ter falhado (retornar null).");
        

        verify(mockConnection, times(1)).prepareStatement(anyString());
        verify(mockPreparedStatement, times(1)).setString(1, "user_errado");
        verify(mockPreparedStatement, times(1)).setString(2, "senha errada");
        verify(mockPreparedStatement, times(1)).executeQuery();

        verify(mockResultSet, never()).getString(anyString()); 
    }
}