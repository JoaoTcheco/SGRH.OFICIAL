/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/UnitTests/JUnit5TestClass.java to edit this template
 */
package dao;

import java.util.List;
import model.Quarto;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.MethodOrderer;
import org.junit.jupiter.api.Order;
import org.junit.jupiter.api.TestMethodOrder;

/**
 *
 * @author User
 */
/**
 * Testes de integração para QuartoDAO.
 * ATENÇÃO: Estes testes modificam a base de dados.
 * Usamos @TestMethodOrder para garantir que o quarto seja criado primeiro e excluído por último.
 * * @author User
 */
@TestMethodOrder(MethodOrderer.OrderAnnotation.class)
public class QuartoDAOTest {
    
    private final QuartoDAO quartoDAO;
    private static final String NUMERO_QUARTO_TESTE = "TESTE999";
    private static int idQuartoTeste; // Armazena o ID do quarto criado

    public QuartoDAOTest() {
        this.quartoDAO = new QuartoDAO();
    }

    /**
     * Testa o cadastro de um novo quarto.
     * Este teste é executado primeiro para garantir que os outros testes tenham um
     * quarto para manipular.
     */
    @Test
    @Order(1)
    public void testCadastrarQuarto() {
        System.out.println("cadastrarQuarto");
        
        Quarto quarto = new Quarto();
        quarto.setNumeroQuarto(NUMERO_QUARTO_TESTE);
        quarto.setTipoQuarto("Suite de Teste");
        quarto.setPrecoPorNoite(9999.00);
        quarto.setEstado("Vago");

        quartoDAO.cadastrarQuarto(quarto);

        // Verifica se o quarto foi realmente inserido
        List<Quarto> quartos = quartoDAO.listarQuartos();
        Quarto quartoEncontrado = null;
        for(Quarto q : quartos){
            if(NUMERO_QUARTO_TESTE.equals(q.getNumeroQuarto())){
                quartoEncontrado = q;
                break;
            }
        }
        
        assertNotNull(quartoEncontrado, "O quarto de teste não foi encontrado na base de dados após o cadastro.");
        assertEquals("Suite de Teste", quartoEncontrado.getTipoQuarto());
        idQuartoTeste = quartoEncontrado.getId(); // Guarda o ID para testes futuros
    }

    /**
     * Testa a listagem de todos os quartos.
     * Verifica se a lista retornada não é nula e não está vazia.
     */
    @Test
    @Order(2)
    public void testListarQuartos() {
        System.out.println("listarQuartos");
        List<Quarto> result = quartoDAO.listarQuartos();
        assertNotNull(result, "A lista de quartos não deveria ser nula.");
        assertFalse(result.isEmpty(), "A lista de quartos não deveria estar vazia.");
    }
    
    /**
     * Testa a busca de um quarto pelo seu ID.
     */
    @Test
    @Order(3)
    public void testGetQuartoById() {
        System.out.println("getQuartoById");
        assertTrue(idQuartoTeste > 0, "O ID do quarto de teste é inválido.");
        Quarto result = quartoDAO.getQuartoById(idQuartoTeste);
        assertNotNull(result, "Deveria encontrar o quarto com o ID de teste.");
        assertEquals(NUMERO_QUARTO_TESTE, result.getNumeroQuarto());
    }
    
    /**
     * Testa a atualização dos dados de um quarto.
     */
    @Test
    @Order(4)
    public void testAtualizarQuarto() {
        System.out.println("atualizarQuarto");
        Quarto quartoParaAtualizar = quartoDAO.getQuartoById(idQuartoTeste);
        assertNotNull(quartoParaAtualizar, "Não foi possível encontrar o quarto para atualizar.");

        quartoParaAtualizar.setTipoQuarto("Suite de Teste Alterada");
        quartoParaAtualizar.setEstado("Manutencao");
        quartoDAO.atualizarQuarto(quartoParaAtualizar);
        
        Quarto quartoAtualizado = quartoDAO.getQuartoById(idQuartoTeste);
        assertEquals("Suite de Teste Alterada", quartoAtualizado.getTipoQuarto());
        assertEquals("Manutencao", quartoAtualizado.getEstado());
    }

    /**
     * Testa a exclusão de um quarto.
     * Este é o último teste a ser executado para limpar os dados de teste.
     */
    @Test
    @Order(5)
    public void testExcluirQuarto() {
        System.out.println("excluirQuarto");
        assertTrue(idQuartoTeste > 0, "O ID do quarto de teste é inválido para exclusão.");
        quartoDAO.excluirQuarto(idQuartoTeste);
        
        Quarto quartoExcluido = quartoDAO.getQuartoById(idQuartoTeste);
        assertNull(quartoExcluido, "O quarto não foi excluído com sucesso, pois ainda foi encontrado na base de dados.");
    }
}