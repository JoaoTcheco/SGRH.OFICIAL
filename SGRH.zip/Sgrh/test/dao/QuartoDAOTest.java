/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/UnitTests/JUnit5TestClass.java to edit this template
 */
package dao;

import java.util.List;
import model.Quarto;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.MethodOrderer;
import org.junit.jupiter.api.Order;
import org.junit.jupiter.api.TestMethodOrder;

/**
 *
 * @author User
 */

@TestMethodOrder(MethodOrderer.OrderAnnotation.class)
public class QuartoDAOTest {
    
    private final QuartoDAO quartoDAO;
    private static final String NUMERO_QUARTO_TESTE = "TESTE999";
    private static int idQuartoTeste; 

    public QuartoDAOTest() {
        this.quartoDAO = new QuartoDAO();
    }

    
    @Test
    @Order(1)
    public void testCadastrarQuarto() {
        System.out.println("cadastrarQuarto");
        
        Quarto quarto = new Quarto();
        quarto.setNumeroQuarto(NUMERO_QUARTO_TESTE);
        quarto.setTipoQuarto("Suite de Teste");
        quarto.setPrecoPorNoite(9999.00);
        quarto.setEstado("Vago");

        quartoDAO.cadastrarQuarto(quarto);

        
        List<Quarto> quartos = quartoDAO.listarQuartos();
        Quarto quartoEncontrado = null;
        for(Quarto q : quartos){
            if(NUMERO_QUARTO_TESTE.equals(q.getNumeroQuarto())){
                quartoEncontrado = q;
                break;
            }
        }
        
        assertNotNull(quartoEncontrado, "O quarto de teste não foi encontrado na base de dados após o cadastro.");
        assertEquals("Suite de Teste", quartoEncontrado.getTipoQuarto());
        idQuartoTeste = quartoEncontrado.getId(); // Guarda o ID para testes NO futuru
    }

    
    @Test
    @Order(2)
    public void testListarQuartos() {
        System.out.println("listarQuartos");
        List<Quarto> result = quartoDAO.listarQuartos();
        assertNotNull(result, "A lista de quartos não deveria ser nula.");
        assertFalse(result.isEmpty(), "A lista de quartos não deveria estar vazia.");
    }
    
    
    @Test
    @Order(3)
    public void testGetQuartoById() {
        System.out.println("getQuartoById");
        assertTrue(idQuartoTeste > 0, "O ID do quarto de teste é inválido.");
        Quarto result = quartoDAO.getQuartoById(idQuartoTeste);
        assertNotNull(result, "Deveria encontrar o quarto com o ID de teste.");
        assertEquals(NUMERO_QUARTO_TESTE, result.getNumeroQuarto());
    }
    
    
    @Test
    @Order(4)
    public void testAtualizarQuarto() {
        System.out.println("atualizarQuarto");
        Quarto quartoParaAtualizar = quartoDAO.getQuartoById(idQuartoTeste);
        assertNotNull(quartoParaAtualizar, "Não foi possível encontrar o quarto para atualizar.");

        quartoParaAtualizar.setTipoQuarto("Suite de Teste Alterada");
        quartoParaAtualizar.setEstado("Manutencao");
        quartoDAO.atualizarQuarto(quartoParaAtualizar);
        
        Quarto quartoAtualizado = quartoDAO.getQuartoById(idQuartoTeste);
        assertEquals("Suite de Teste Alterada", quartoAtualizado.getTipoQuarto());
        assertEquals("Manutencao", quartoAtualizado.getEstado());
    }

    
    @Test
    @Order(5)
    public void testExcluirQuarto() {
        System.out.println("excluirQuarto");
        assertTrue(idQuartoTeste > 0, "O ID do quarto de teste é inválido para exclusão.");
        quartoDAO.excluirQuarto(idQuartoTeste);
        
        Quarto quartoExcluido = quartoDAO.getQuartoById(idQuartoTeste);
        assertNull(quartoExcluido, "O quarto não foi excluído com sucesso, pois ainda foi encontrado na base de dados.");
    }
}