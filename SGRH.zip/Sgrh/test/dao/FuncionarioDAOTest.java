/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/UnitTests/JUnit5TestClass.java to edit this template
 */
package dao;

import model.Funcionario;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

/**
 *
 * @author User
 */
public class FuncionarioDAOTest {
    
    public FuncionarioDAOTest() {
    }
    
    @BeforeAll
    public static void setUpClass() {
    }
    
    @AfterAll
    public static void tearDownClass() {
    }
    
    @BeforeEach
    public void setUp() {
    }
    
    @AfterEach
    public void tearDown() {
    }

    // TODO add test methods here.
    // The methods must be annotated with annotation @Test. For example:
    //
    // @Test
    // public void hello() {}
    /**
     * Testa a autenticação de um funcionário com credenciais válidas.
     * Espera-se que o método retorne um objeto Funcionario não nulo.
     */
    @Test
    public void testAutenticacaoFuncionario_ComCredenciaisValidas() {
        System.out.println("autenticacaoFuncionario com credenciais válidas");
        
        Funcionario objFuncionario = new Funcionario();
        objFuncionario.setUsername("admin"); // Use um user válido da sua BD
        objFuncionario.setSenha("1234");    // Use a senha correspondente

        FuncionarioDAO instance = new FuncionarioDAO();
        Funcionario result = instance.autenticacaoFuncionario(objFuncionario);
        
        assertNotNull(result, "O funcionário deveria ter sido autenticado com sucesso, mas o resultado foi nulo.");
        assertEquals("admin", result.getUsername(), "O username do funcionário autenticado não corresponde ao esperado.");
    }

    /**
     * Testa a autenticação de um funcionário com credenciais inválidas.
     * Espera-se que o método retorne null.
     */
    @Test
    public void testAutenticacaoFuncionario_ComCredenciaisInvalidas() {
        System.out.println("autenticacaoFuncionario com credenciais inválidas");

        Funcionario objFuncionario = new Funcionario();
        objFuncionario.setUsername("usuario_invalido");
        objFuncionario.setSenha("senha_errada");

        FuncionarioDAO instance = new FuncionarioDAO();
        Funcionario result = instance.autenticacaoFuncionario(objFuncionario);

        assertNull(result, "A autenticação com credenciais inválidas deveria falhar (retornar null), mas retornou um objeto.");
    }
    
}

